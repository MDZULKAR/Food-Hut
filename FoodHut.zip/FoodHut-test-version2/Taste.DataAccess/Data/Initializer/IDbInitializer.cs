﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodHut.DataAccess.Data.Initializer
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
